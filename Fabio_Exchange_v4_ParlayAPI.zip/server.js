const express=require("express");
const path=require("path");
const app=express(); const PORT=process.env.PORT||3000;
const KEY=process.env.PARLAY_API_KEY||"";
const BASE="https://parlay-api.com/v1";
app.use(express.static(path.join(__dirname,"public")));

const sports=[
 ["soccer_brasileirao_serie_a","Futebol"],["soccer_brasileirao_serie_b","Futebol"],
 ["soccer_epl","Futebol"],["soccer_spain_la_liga","Futebol"],
 ["basketball_nba","Basquete"],["basketball_wnba","Basquete"],
 ["tennis_atp","Tênis"],["tennis_wta","Tênis"]
];

app.get("/api/status",(req,res)=>res.json({connected:Boolean(KEY),provider:"ParlayAPI",mode:KEY?"REAL":"DEMO"}));

async function api(sport,live=false){
 const u=new URL(`${BASE}/sports/${sport}/${live?"live":"odds"}`);
 u.searchParams.set("regions","br");
 u.searchParams.set("markets","h2h");
 u.searchParams.set("oddsFormat","decimal");
 if(!live) u.searchParams.set("include_live","true");
 const r=await fetch(u,{headers:{"X-API-Key":KEY}});
 const body=await r.text();
 if(!r.ok) throw new Error(`ParlayAPI ${r.status}: ${body.slice(0,300)}`);
 return JSON.parse(body);
}

function normalize(items,sportName){
 const out=[];
 for(const e of (Array.isArray(items)?items:[])){
   const home=e.home_team||e.homeTeam||e.home;
   const away=e.away_team||e.awayTeam||e.away;
   if(!home||!away) continue;
   const markets=e.bookmakers||e.books||[];
   const quotes=[];
   for(const b of markets){
     for(const m of (b.markets||[])){
       if(m.key!=="h2h" && m.market_key!=="h2h") continue;
       for(const o of (m.outcomes||m.selections||[])){
         const price=Number(o.price);
         if(price>1) quotes.push({name:o.name,price,bookmaker:b.title||b.key||"book"});
       }
     }
   }
   const best={};
   for(const q of quotes) if(!best[q.name]||q.price>best[q.name].price) best[q.name]=q;
   const names=Object.keys(best);
   out.push({
     sport:sportName, league:e.sport_title||e.league||"Ao vivo",
     home,away,score:e.score||"",clock:e.clock||e.status||"",
     markets:names.map(n=>[n,best[n].price.toFixed(2),best[n].price.toFixed(2)]),
     event_id:e.id||e.event_id, updated:e.last_update||e.commence_time||null
   });
 }
 return out;
}

app.get("/api/live",async(req,res)=>{
 if(!KEY) return res.json({mode:"DEMO",events:[]});
 const all=[];
 for(const [key,name] of sports){
   try{
     const data=await api(key,true);
     all.push(...normalize(data,name));
   }catch(e){ /* sport without current coverage is skipped */ }
 }
 res.json({mode:"REAL",events:all});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Fabio Exchange V4: http://localhost:${PORT}`));