# Fabio Exchange V4

Versão configurada especificamente para ParlayAPI.

1. Copie `.env.example` para `.env`.
2. Coloque sua NOVA chave em PARLAY_API_KEY.
3. `npm install`
4. `npm start`
5. Abra http://localhost:3000

O backend consulta `/v1/sports/{sport}/live` com `X-API-Key`, usando odds em formato decimal e região `br`. O sistema mantém saldo e apostas apenas fictícios.

A V4 usa polling de 30 segundos, adequado para teste. O plano Free do ParlayAPI permite polling, enquanto streaming completo de odds requer plano Business+; consulte a documentação atual antes de contratar. 
